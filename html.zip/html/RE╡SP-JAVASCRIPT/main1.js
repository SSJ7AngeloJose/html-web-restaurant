
var coche = {
    modelo: 'Mercedes Clase A',
    maxima:500,
    antiguedad: 2020,
    mostrarDatos(){
     console.log(this.modelo,this.maxima,this.antiguedad)
    },
    propiedad1: "valor aleatorio"
  };
  document.write("<h1>"+coche.antiguedad +"</h1> ")
  coche.mostrarDatos();
  console.log(coche);
  

  var saludar = new Promise((resolve, reject) => {
  setTimeout(() => {
      let saludo = "holaaa !!";
      //por que si hay error = saludo = false;
      if(saludo){
         resolve(saludo);
      }else{
        reject('no hay saludo disponible');
      }
  }, 2000);

  });
  saludar.then(resultado => {

    alert(resultado);
    //por si hay error = alert(err);
})

.catch(err => {
    alert( error  );
});