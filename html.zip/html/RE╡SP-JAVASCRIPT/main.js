//alertas
//alert("hola bienvenido")

//variables
 let nombre = 'Angelo';
 nombre = 'Angelo JOse Agurto  ';
//constantes
const apellido = 'Laura';
//otra variable
let altura = 187;

//mostrar consola
 console.log(nombre);
console.log(altura);

//concatenacion
let concatenacion = nombre + ' ' + apellido;

//seleccionar elemntos de la pagina
let datos = document.querySelector("#datos");
datos.innerHTML =  ` 
  <h1> Soy la caja de datos</h1>
   <h2> mi nombre es : ${concatenacion}</h2>
   <h3> mi altura es : ${altura}</h3>
  ` ;

  //condiciones}if else 
  altura = 180;
  if(altura >= 185){
    datos.innerHTML = "<h1>Eres una Persona alta</h1>"
  }else{
    datos.innerHTML += "<h1>Eres una Persona bajita</h1>"
  }

  //bucles
  for(let year = 2000; year <= 2023; year++){
    datos.innerHTML += `<h2>Estamos en el año: ${year}</h2> ` ;
  }

//Arrays variable let
let nombres = ['Angelo', 'francisco', 'juan'];
let divNombres = document.querySelector('#nombres');
//opcion 1 hacerlo asi solo se muestre solo  un nombre
//divNombres.innerHTML = nombres[0];
//opcion 2 hacerlo de esta manera que mostrara todo los nombres
//divNombres.innerHTML = "<h1>Listado de Nombres</h1><ul>";
//nombres.forEach(nombre => {
//divNombres.innerHTML += "<li>"+ nombre+"</li>";
//)
//divNombres.innerHTML += "</ul>" 
//opcion 3 hacaerlo de esta manera mas rapido
divNombres.innerHTML = "<h1>Listado de Nombres</h1><ul>";
for (let nombre of nombres){
  divNombres.innerHTML += "<li>"+ nombre+"</li>";
}
divNombres.innerHTML += "</ul>" 

//funciones 
const miInformacion = (nombre, altura) => {
  let misDatos =` 
  <h1> Soy la caja de datos</h1>
   <h2> mi nombre es : ${concatenacion}</h2>
   <h3> mi altura es : ${altura}</h3>
  `;
  return misDatos;
}
 
const imprimir = () => {
  let datos = document.querySelector("#datos");
 datos.innerHTML = miInformacion("Jose",187);
}
imprimir();

 







