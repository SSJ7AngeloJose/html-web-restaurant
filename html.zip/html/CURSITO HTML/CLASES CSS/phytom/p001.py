print("bienvenido al mundo de PYHTOM")
print( 1 +1  )
print( 2*2 )
 