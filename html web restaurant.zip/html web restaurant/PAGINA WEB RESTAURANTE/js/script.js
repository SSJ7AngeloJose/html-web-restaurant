document.addEventListener('DOMContentLoaded', () => {
    const reservationForm = document.getElementById('reservation-form');
    
    reservationForm.addEventListener('submit', (event) => {
        event.preventDefault();
        
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const date = document.getElementById('date').value;
        const time = document.getElementById('time').value;
        const guests = document.getElementById('guests').value;
        
        // Aquí puedes agregar la lógica para enviar la reservación a un servidor o mostrar un mensaje de confirmación.
        alert(`Reservación confirmada para ${name} el ${date} a las ${time} para ${guests} invitados. Confirmación enviada a ${email}.`);
    });
});

